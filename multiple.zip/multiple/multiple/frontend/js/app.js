/**
 * app.js - 投资组合管理系统核心逻辑
 */

// 全局应用状态
const appState = {
  portfolioItems: [],
  selectedItem: null,
  totalValue: 0,
  initialValue: 0,
  totalReturn: 0,
  isLoading: false
};

// DOM元素引用
const elements = {
  portfolioList: document.getElementById('portfolio-list'),
  summaryValue: document.getElementById('summary-value'),
  summaryReturn: document.getElementById('summary-return'),
  returnPercentage: document.getElementById('return-percentage'),
  returnArrow: document.getElementById('return-arrow'),
  loadingIndicator: document.getElementById('loading-indicator'),
  addItemBtn: document.getElementById('add-item-btn'),
  modal: document.getElementById('portfolio-modal'),
  modalTitle: document.getElementById('modal-title'),
  modalForm: document.getElementById('portfolio-form'),
  closeModalBtn: document.getElementById('close-modal'),
  cancelBtn: document.getElementById('cancel-btn'),
  typeSelector: document.getElementById('item-type'),
  stockFields: document.getElementById('stock-fields'),
  stockBondFields: document.getElementById('stock-bond-fields'),
  cashFields: document.getElementById('cash-fields'),
  refreshBtn: document.getElementById('refresh-btn'),
  errorContainer: document.getElementById('error-container')
};

/**
 * 初始化应用
 */
async function initializeApp() {
  setupEventListeners();
  await loadPortfolioData();
  initializeCharts();
}

/**
 * 设置所有事件监听器
 */
function setupEventListeners() {
  // 添加项目按钮
  elements.addItemBtn.addEventListener('click', () => openModal('add'));
  
  // 关闭模态框
  elements.closeModalBtn.addEventListener('click', closeModal);
  elements.cancelBtn.addEventListener('click', closeModal);
  
  // 点击模态框外部关闭
  window.addEventListener('click', (e) => {
    if (e.target === elements.modal) closeModal();
  });
  
  // 表单提交
  elements.modalForm.addEventListener('submit', handleFormSubmit);
  
  // 资产类型切换
  elements.typeSelector.addEventListener('change', updateFormFields);
  
  // 刷新数据
  elements.refreshBtn.addEventListener('click', loadPortfolioData);
}

/**
 * 加载投资组合数据
 */
async function loadPortfolioData() {
  try {
    setLoading(true);
    clearError();
    
    // 获取项目数据和表现数据
    const [items, performance] = await Promise.all([
      api.fetchPortfolioItems(),
      api.fetchPortfolioPerformance()
    ]);
    
    appState.portfolioItems = items;
    renderPortfolioList();
    calculatePortfolioSummary(performance.summary);
    updateCharts(performance);
    
    setLoading(false);
  } catch (error) {
    showError(`加载失败: ${error.message}`);
    setLoading(false);
  }
}

/**
 * 渲染投资项目列表
 */
function renderPortfolioList() {
  elements.portfolioList.innerHTML = '';
  
  if (appState.portfolioItems.length === 0) {
    elements.portfolioList.innerHTML = `
      <div class="empty-state">
        <p>投资组合为空</p>
        <p>点击"添加新项目"开始构建您的投资组合</p>
      </div>
    `;
    return;
  }
  
  appState.portfolioItems.forEach(item => {
    const card = createPortfolioItemCard(item);
    elements.portfolioList.appendChild(card);
  });
}

/**
 * 创建单个投资项目卡片
 */
function createPortfolioItemCard(item) {
  const card = document.createElement('div');
  card.className = 'portfolio-item';
  card.dataset.id = item.id;
  
  // 计算价值和收益
  const { currentValue, initialValue, returnPercentage, returnClass } = calculateItemMetrics(item);
  
  // 项目详情HTML
  let itemDetails = '';
  if (item.type === 'stock') {
    itemDetails = `
      <div class="item-ticker">代码: ${item.ticker}</div>
      <div class="item-quantity">数量: ${item.quantity} 股</div>
    `;
  } else if (item.type === 'bond') {
    itemDetails = `<div class="item-quantity">数量: ${item.quantity} 单位</div>`;
  } else if (item.type === 'cash') {
    itemDetails = `<div class="item-type">现金</div>`;
  }
  
  card.innerHTML = `
    <div class="item-header">
      <div class="item-name">${item.name}</div>
      <div class="item-actions">
        <button class="edit-btn" data-id="${item.id}">
          <i class="fas fa-edit"></i> 编辑
        </button>
        <button class="delete-btn" data-id="${item.id}">
          <i class="fas fa-trash"></i> 删除
        </button>
      </div>
    </div>
    <div class="item-details">${itemDetails}</div>
    <div class="item-values">
      <div class="value-column">
        <div class="value-label">当前价值</div>
        <div class="current-value">${formatCurrency(currentValue)}</div>
      </div>
      <div class="value-column">
        <div class="value-label">初始价值</div>
        <div class="initial-value">${formatCurrency(initialValue)}</div>
      </div>
      <div class="value-column">
        <div class="value-label">收益</div>
        <div class="return-value ${returnClass}">
          ${returnPercentage >= 0 ? '+' : ''}${returnPercentage.toFixed(2)}%
        </div>
      </div>
    </div>
  `;
  
  // 绑定编辑/删除事件
  card.querySelector('.edit-btn').addEventListener('click', () => {
    openModal('edit', item);
  });
  card.querySelector('.delete-btn').addEventListener('click', () => {
    confirmDelete(item.id);
  });
  
  return card;
}

/**
 * 计算项目 metrics
 */
function calculateItemMetrics(item) {
  let currentValue, initialValue, returnPercentage, returnClass;
  
  if (item.type === 'cash') {
    currentValue = item.value || 0;
    initialValue = item.value || 0;
    returnPercentage = 0;
    returnClass = 'neutral';
  } else {
    currentValue = (item.current_price || 0) * (item.quantity || 0);
    initialValue = (item.purchase_price || 0) * (item.quantity || 0);
    returnPercentage = initialValue > 0 ? ((currentValue - initialValue) / initialValue) * 100 : 0;
    returnClass = returnPercentage >= 0 ? 'positive' : 'negative';
  }
  
  return { currentValue, initialValue, returnPercentage, returnClass };
}

/**
 * 计算投资组合汇总
 */
function calculatePortfolioSummary(summary) {
  appState.totalValue = summary.totalCurrentValue;
  appState.initialValue = summary.totalInitialValue;
  appState.totalReturn = summary.overallPerformance;
  
  // 更新UI
  elements.summaryValue.textContent = formatCurrency(appState.totalValue);
  elements.summaryReturn.textContent = formatCurrency(appState.totalValue - appState.initialValue);
  elements.returnPercentage.textContent = `${appState.totalReturn >= 0 ? '+' : ''}${appState.totalReturn}%`;
  
  // 更新收益箭头
  if (appState.totalReturn > 0) {
    elements.returnArrow.className = 'fas fa-arrow-up positive';
    elements.returnPercentage.className = 'positive';
  } else if (appState.totalReturn < 0) {
    elements.returnArrow.className = 'fas fa-arrow-down negative';
    elements.returnPercentage.className = 'negative';
  } else {
    elements.returnArrow.className = 'fas fa-minus neutral';
    elements.returnPercentage.className = 'neutral';
  }
}

/**
 * 打开模态框
 * @param {string} mode - 'add' 或 'edit'
 * @param {Object} item - 编辑时的项目数据
 */
function openModal(mode, item = null) {
  elements.modalTitle.textContent = mode === 'add' ? '添加投资项目' : '编辑投资项目';
  elements.modalForm.reset();
  appState.selectedItem = item;
  
  // 重置表单状态
  document.getElementById('item-id').value = '';
  elements.typeSelector.disabled = mode === 'edit';
  
  if (mode === 'edit' && item) {
    // 填充编辑数据
    document.getElementById('item-id').value = item.id;
    elements.typeSelector.value = item.type;
    document.getElementById('item-name').value = item.name;
    
    // 填充不同类型的字段
    if (item.type === 'stock') {
      document.getElementById('ticker-symbol').value = item.ticker || '';
      document.getElementById('item-quantity').value = item.quantity || '';
      document.getElementById('purchase-price').value = item.purchase_price || '';
      document.getElementById('purchase-date').value = item.purchase_date || '';
    } else if (item.type === 'bond') {
      document.getElementById('item-quantity').value = item.quantity || '';
      document.getElementById('purchase-price').value = item.purchase_price || '';
      document.getElementById('purchase-date').value = item.purchase_date || '';
    } else if (item.type === 'cash') {
      document.getElementById('cash-value').value = item.value || '';
    }
  }
  
  // 更新表单显示
  updateFormFields();
  elements.modal.style.display = 'block';
}

/**
 * 关闭模态框
 */
function closeModal() {
  elements.modal.style.display = 'none';
  appState.selectedItem = null;
}

/**
 * 根据资产类型更新表单字段显示
 */
function updateFormFields() {
  const type = elements.typeSelector.value;
  
  // 重置显示状态
  elements.stockFields.style.display = 'none';
  elements.stockBondFields.style.display = 'none';
  elements.cashFields.style.display = 'none';
  
  // 根据类型显示对应字段
  if (type === 'stock') {
    elements.stockFields.style.display = 'block';
    elements.stockBondFields.style.display = 'block';
  } else if (type === 'bond') {
    elements.stockBondFields.style.display = 'block';
  } else if (type === 'cash') {
    elements.cashFields.style.display = 'block';
  }
}

/**
 * 处理表单提交
 */
async function handleFormSubmit(e) {
  e.preventDefault();
  const type = elements.typeSelector.value;
  const id = document.getElementById('item-id').value;
  
  // 收集表单数据
  const formData = {
    type,
    name: document.getElementById('item-name').value
  };
  
  // 根据类型添加特有字段
  if (type === 'stock') {
    Object.assign(formData, {
      ticker: document.getElementById('ticker-symbol').value,
      quantity: parseFloat(document.getElementById('item-quantity').value),
      purchase_price: parseFloat(document.getElementById('purchase-price').value),
      purchase_date: document.getElementById('purchase-date').value
    });
  } else if (type === 'bond') {
    Object.assign(formData, {
      quantity: parseFloat(document.getElementById('item-quantity').value),
      purchase_price: parseFloat(document.getElementById('purchase-price').value),
      purchase_date: document.getElementById('purchase-date').value
    });
  } else if (type === 'cash') {
    formData.value = parseFloat(document.getElementById('cash-value').value);
  }
  
  try {
    // 新增或更新项目
    if (id) {
      await api.updatePortfolioItem(id, formData);
    } else {
      await api.addPortfolioItem(formData);
    }
    
    closeModal();
    await loadPortfolioData(); // 重新加载数据
  } catch (error) {
    showError(`操作失败: ${error.message}`);
  }
}

/**
 * 确认删除项目
 */
async function confirmDelete(id) {
  if (confirm('确定要删除这个项目吗？')) {
    try {
      await api.deletePortfolioItem(id);
      await loadPortfolioData(); // 重新加载数据
    } catch (error) {
      showError(`删除失败: ${error.message}`);
    }
  }
}

/**
 * 格式化货币
 */
function formatCurrency(value) {
  return new Intl.NumberFormat('zh-CN', {
    style: 'currency',
    currency: 'CNY',
    minimumFractionDigits: 2
  }).format(value);
}

/**
 * 设置加载状态
 */
function setLoading(isLoading) {
  appState.isLoading = isLoading;
  elements.loadingIndicator?.classList.toggle('active', isLoading);
  elements.refreshBtn.disabled = isLoading;
  elements.addItemBtn.disabled = isLoading;
}

/**
 * 显示错误信息
 */
function showError(message) {
  elements.errorContainer.textContent = message;
  elements.errorContainer.style.display = 'block';
  // 3秒后自动隐藏
  setTimeout(clearError, 3000);
}

/**
 * 清除错误信息
 */
function clearError() {
  elements.errorContainer.textContent = '';
  elements.errorContainer.style.display = 'none';
}

// 初始化图表
function initializeCharts() {
  window.chartFunctions.initializeChart();
}

// 更新图表
function updateCharts(performanceData) {
  window.chartFunctions.updatePerformanceChart(performanceData);
}

// 页面加载完成后初始化应用
document.addEventListener('DOMContentLoaded', initializeApp);