// 与后端API交互的服务
const API_URL = 'http://localhost:3000/api/portfolio';

/**
 * 获取所有投资组合项目
 */
async function fetchPortfolioItems() {
  try {
    const response = await fetch(API_URL);
    if (!response.ok) throw new Error(`HTTP错误: ${response.status}`);
    return await response.json();
  } catch (error) {
    console.error('获取投资项目失败:', error);
    throw error;
  }
}

/**
 * 获取投资组合表现数据
 */
async function fetchPortfolioPerformance() {
  try {
    const response = await fetch(`${API_URL}/performance`);
    if (!response.ok) throw new Error(`HTTP错误: ${response.status}`);
    return await response.json();
  } catch (error) {
    console.error('获取表现数据失败:', error);
    throw error;
  }
}

/**
 * 添加新投资项目
 * @param {Object} item - 投资项目数据
 */
async function addPortfolioItem(item) {
  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(item)
    });
    if (!response.ok) throw new Error(`HTTP错误: ${response.status}`);
    return await response.json();
  } catch (error) {
    console.error('添加投资项目失败:', error);
    throw error;
  }
}

/**
 * 更新投资项目
 * @param {number} id - 项目ID
 * @param {Object} item - 更新后的项目数据
 */
async function updatePortfolioItem(id, item) {
  try {
    const response = await fetch(`${API_URL}/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(item)
    });
    if (!response.ok) throw new Error(`HTTP错误: ${response.status}`);
    return await response.json();
  } catch (error) {
    console.error('更新投资项目失败:', error);
    throw error;
  }
}

/**
 * 删除投资项目
 * @param {number} id - 项目ID
 */
async function deletePortfolioItem(id) {
  try {
    const response = await fetch(`${API_URL}/${id}`, {
      method: 'DELETE'
    });
    if (!response.ok) throw new Error(`HTTP错误: ${response.status}`);
    return await response.json();
  } catch (error) {
    console.error('删除投资项目失败:', error);
    throw error;
  }
}

// 暴露API方法
window.api = {
  fetchPortfolioItems,
  fetchPortfolioPerformance,
  addPortfolioItem,
  updatePortfolioItem,
  deletePortfolioItem
};