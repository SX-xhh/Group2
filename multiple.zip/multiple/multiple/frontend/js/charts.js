// 图表渲染功能
let performanceChart = null;

/**
 * 初始化表现图表
 */
function initializeChart() {
  const ctx = document.getElementById('performanceChart').getContext('2d');
  
  performanceChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: [],
      datasets: [
        {
          label: '初始价值',
          backgroundColor: 'rgba(54, 162, 235, 0.5)',
          borderColor: 'rgb(54, 162, 235)',
          borderWidth: 1,
          data: [],
          performanceData: []
        },
        {
          label: '当前价值',
          backgroundColor: 'rgba(255, 99, 132, 0.5)',
          borderColor: 'rgb(255, 99, 132)',
          borderWidth: 1,
          data: [],
          performanceData: []
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          title: { display: true, text: '价值 (元)' }
        },
        x: {
          title: { display: true, text: '投资项目' }
        }
      },
      plugins: {
        tooltip: {
          callbacks: {
            footer: (tooltipItems) => {
              const perf = tooltipItems[0].dataset.performanceData[tooltipItems[0].dataIndex];
              return perf ? `收益: ${perf.toFixed(2)}%` : '';
            }
          }
        },
        legend: { position: 'top' }
      }
    }
  });
}

/**
 * 更新表现图表数据
 * @param {Object} performanceData - 从API获取的表现数据
 */
function updatePerformanceChart(performanceData) {
  
  if (!performanceChart) initializeChart();
  
  const labels = [];
  const initialValues = [];
  const currentValues = [];
  const performancePercentages = [];
  
  performanceData.items.forEach(item => {
    labels.push(item.name);
    initialValues.push(Number(item.initial_value));
    currentValues.push(Number(item.current_value));
    performancePercentages.push(Number(item.performance));
  });
  
  // 更新图表数据
  performanceChart.data.labels = labels;
  performanceChart.data.datasets[0].data = initialValues;
  performanceChart.data.datasets[1].data = currentValues;
  performanceChart.data.datasets[0].performanceData = performancePercentages;
  performanceChart.data.datasets[1].performanceData = performancePercentages;
  
  performanceChart.update();
}

// 暴露图表方法
window.chartFunctions = {
  initializeChart,
  updatePerformanceChart
};