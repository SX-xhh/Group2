// API service for interacting with the backend

const API_URL = 'http://localhost:3000/api/portfolio';

// Get all portfolio items
async function getPortfolioItems() {
  try {
    const response = await fetch(API_URL);
    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error('Error fetching portfolio items:', error);
    throw error;
  }
}

// Get portfolio performance data
async function getPortfolioPerformance() {
  try {
    const response = await fetch(`${API_URL}/performance`);
    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error('Error fetching portfolio performance:', error);
    throw error;
  }
}

// Add a new portfolio item
async function addPortfolioItem(item) {
  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(item)
    });
    
    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error adding portfolio item:', error);
    throw error;
  }
}

// Update a portfolio item
async function updatePortfolioItem(id, item) {
  try {
    const response = await fetch(`${API_URL}/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(item)
    });
    
    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error updating portfolio item:', error);
    throw error;
  }
}

// Delete a portfolio item
async function deletePortfolioItem(id) {
  try {
    const response = await fetch(`${API_URL}/${id}`, {
      method: 'DELETE'
    });
    
    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error deleting portfolio item:', error);
    throw error;
  }
}
