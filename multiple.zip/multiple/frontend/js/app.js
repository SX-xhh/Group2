/**
 * app.js - 投资组合管理系统的主要应用逻辑
 * 
 * 这个文件处理用户界面交互、数据处理和应用状态管理
 */

// 全局应用状态
const appState = {
    portfolioItems: [],
    selectedItem: null,
    totalValue: 0,
    initialValue: 0,
    totalReturn: 0,
    isLoading: false
  };
  
  // DOM 元素
  const elements = {
    portfolioList: document.getElementById('portfolio-list'),
    summaryValue: document.getElementById('summary-value'),
    summaryReturn: document.getElementById('summary-return'),
    returnPercentage: document.getElementById('return-percentage'),
    returnArrow: document.getElementById('return-arrow'),
    loadingIndicator: document.getElementById('loading-indicator'),
    addItemBtn: document.getElementById('add-item-btn'),
    modal: document.getElementById('portfolio-modal'),
    modalTitle: document.getElementById('modal-title'),
    modalForm: document.getElementById('portfolio-form'),
    closeModalBtn: document.getElementById('close-modal'),
    typeSelector: document.getElementById('item-type'),
    stockFields: document.getElementById('stock-fields'),
    bondFields: document.getElementById('bond-fields'),
    cashFields: document.getElementById('cash-fields'),
    refreshBtn: document.getElementById('refresh-btn'),
    errorContainer: document.getElementById('error-container')
  };
  
  /**
   * 初始化应用
   */
  async function initializeApp() {
    // 设置事件监听器
    setupEventListeners();
    
    // 加载投资组合数据
    await loadPortfolioData();
    
    // 初始化图表
    initializeCharts();
  }
  
  /**
   * 设置所有事件监听器
   */
  function setupEventListeners() {
    // 添加新项目按钮
    elements.addItemBtn.addEventListener('click', () => {
      openModal('add');
    });
    
    // 关闭模态框
    elements.closeModalBtn.addEventListener('click', closeModal);
    
    // 模态框外部点击关闭
    window.addEventListener('click', (event) => {
      if (event.target === elements.modal) {
        closeModal();
      }
    });
    
    // 表单提交
    elements.modalForm.addEventListener('submit', handleFormSubmit);
    
    // 资产类型选择器变化
    elements.typeSelector.addEventListener('change', updateFormFields);
    
    // 刷新按钮
    elements.refreshBtn.addEventListener('click', loadPortfolioData);
  }
  
  /**
   * 加载投资组合数据
   */
  async function loadPortfolioData() {
    try {
      setLoading(true);
      
      // 从API获取数据
      const items = await fetchPortfolioItems();
      appState.portfolioItems = items;
      
      // 更新UI
      renderPortfolioList();
      calculatePortfolioSummary();
      updateCharts();
      
      setLoading(false);
    } catch (error) {
      showError(`加载数据失败: ${error.message}`);
      setLoading(false);
    }
  }
  
  /**
   * 渲染投资组合列表
   */
  function renderPortfolioList() {
    elements.portfolioList.innerHTML = '';
    
    appState.portfolioItems.forEach(item => {
      const card = createPortfolioItemCard(item);
      elements.portfolioList.appendChild(card);
    });
    
    if (appState.portfolioItems.length === 0) {
      elements.portfolioList.innerHTML = `
        <div class="empty-state">
          <p>您的投资组合中没有项目。</p>
          <p>点击"添加新项目"按钮开始构建您的投资组合。</p>
        </div>
      `;
    }
  }
  
  /**
   * 创建单个投资项目卡片
   */
  function createPortfolioItemCard(item) {
    const card = document.createElement('div');
    card.className = 'portfolio-item';
    card.setAttribute('data-id', item.id);
    
    let currentValue = 0;
    let initialValue = 0;
    let returnPercentage = 0;
    let returnClass = '';
    
    if (item.type === 'cash') {
      currentValue = item.value;
      initialValue = item.value;
      returnPercentage = 0;
      returnClass = 'neutral';
    } else {
      currentValue = item.current_price * item.quantity;
      initialValue = item.purchase_price * item.quantity;
      returnPercentage = ((currentValue - initialValue) / initialValue) * 100;
      returnClass = returnPercentage >= 0 ? 'positive' : 'negative';
    }
    
    const formattedCurrentValue = formatCurrency(currentValue);
    const formattedInitialValue = formatCurrency(initialValue);
    const formattedReturn = returnPercentage.toFixed(2);
    
    let itemDetails = '';
    if (item.type === 'stock') {
      itemDetails = `<div class="item-ticker">${item.ticker}</div>
                    <div class="item-quantity">${item.quantity} 股</div>`;
    } else if (item.type === 'bond') {
      itemDetails = `<div class="item-quantity">${item.quantity} 单位</div>`;
    } else if (item.type === 'cash') {
      itemDetails = `<div class="item-type">现金</div>`;
    }
    
    card.innerHTML = `
      <div class="item-header">
        <div class="item-name">${item.name}</div>
        <div class="item-actions">
          <button class="edit-btn" data-id="${item.id}">
            <i class="fas fa-edit"></i>
          </button>
          <button class="delete-btn" data-id="${item.id}">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      </div>
      <div class="item-details">
        ${itemDetails}
      </div>
      <div class="item-values">
        <div class="value-column">
          <div class="value-label">当前价值</div>
          <div class="current-value">${formattedCurrentValue}</div>
        </div>
        <div class="value-column">
          <div class="value-label">初始价值</div>
          <div class="initial-value">${formattedInitialValue}</div>
        </div>
        <div class="value-column">
          <div class="value-label">收益</div>
          <div class="return-value ${returnClass}">
            ${returnPercentage >= 0 ? '+' : ''}${formattedReturn}%
          </div>
        </div>
      </div>
    `;
    
    // 添加事件监听器
    card.querySelector('.edit-btn').addEventListener('click', () => {
      openModal('edit', item);
    });
    
    card.querySelector('.delete-btn').addEventListener('click', () => {
      confirmDelete(item);
    });
    
    return card;
  }
  
  /**
   * 计算投资组合汇总数据
   */
  function calculatePortfolioSummary() {
    let totalValue = 0;
    let initialValue = 0;
    
    appState.portfolioItems.forEach(item => {
      if (item.type === 'cash') {
        totalValue += item.value;
        initialValue += item.value;
      } else {
        totalValue += item.current_price * item.quantity;
        initialValue += item.purchase_price * item.quantity;
      }
    });
    
    appState.totalValue = totalValue;
    appState.initialValue = initialValue;
    appState.totalReturn = ((totalValue - initialValue) / initialValue) * 100;
    
    // 更新UI
    elements.summaryValue.textContent = formatCurrency(totalValue);
    elements.summaryReturn.textContent = formatCurrency(totalValue - initialValue);
    elements.returnPercentage.textContent = `${appState.totalReturn >= 0 ? '+' : ''}${appState.totalReturn.toFixed(2)}%`;
    
    // 更新收益箭头和颜色
    if (appState.totalReturn > 0) {
      elements.returnArrow.className = 'fas fa-arrow-up positive';
      elements.returnPercentage.className = 'positive';
    } else if (appState.totalReturn < 0) {
      elements.returnArrow.className = 'fas fa-arrow-down negative';
      elements.returnPercentage.className = 'negative';
    } else {
      elements.returnArrow.className = 'fas fa-minus neutral';
      elements.returnPercentage.className = 'neutral';
    }
  }
  
  /**
   * 打开模态框
   */
  function openModal(mode, item = null) {
    elements.modalTitle.textContent = mode === 'add' ? '添加投资项目' : '编辑投资项目';
    elements.modalForm.reset();
    
    appState.selectedItem = item;
    
    if (mode === 'edit' && item) {
      // 填充表单数据
      elements.typeSelector.value = item.type;
      updateFormFields();
      
      if (item.type === 'stock') {
        document.getElementById('ticker-symbol').value = item.ticker;
        document.getElementById('stock-name').value = item.name;
        document.getElementById('stock-quantity').value = item.quantity;
        document.getElementById('purchase-price').value = item.purchase_price;
        document.getElementById('purchase-date').value = item.purchase_date;
      } else if (item.type === 'bond') {
        document.getElementById('bond-name').value = item.name;
        document.getElementById('bond-quantity').value = item.quantity;
        document.getElementById('bond-purchase-price').value = item.purchase_price;
        document.getElementById('bond-purchase-date').value = item.purchase_date;
      } else if (item.type === 'cash') {
        document.getElementById('cash-name').value = item.name;
        document.getElementById('cash-value').value = item.value;
      }
      
      // 禁用类型选择器 - 编辑时不允许改变类型
      elements.typeSelector.disabled = true;
    } else {
      elements.typeSelector.disabled = false;
      // 默认选择股票类型
      elements.typeSelector.value = 'stock';
      updateFormFields();
    }
    
    elements.modal.style.display = 'block';
  }
  
  /**
   * 关闭模态框
   */
  function closeModal() {
    elements.modal.style.display = 'none';
    elements.modalForm.reset();
    appState.selectedItem = null;
  }
  
  /**
   * 根据选择的资产类型更新表单字段
   */
  function updateFormFields() {
    const selectedType = elements.typeSelector.value;
    
    // 隐藏所有字段组
    elements.stockFields.style.display = 'none';
    elements.bondFields.style.display = 'none';
    elements.cashFields.style.display = 'none';
    
    // 显示选定类型的字段
    if (selectedType === 'stock') {
      elements.stockFields.style.display = 'block';
    } else if (selectedType === 'bond') {
      elements.bondFields.style.display = 'block';
    } else if (selectedType === 'cash') {
      elements.cashFields.style.display = 'block';
    }
  }
  
  /**
   * 处理表单提交
   */
  async function handleFormSubmit(event) {
    event.preventDefault();
    
    try {
      setLoading(true);
      
      const formData = new FormData(elements.modalForm);
      const itemType = formData.get('item-type');
      
      let itemData = {
        type: itemType
      };
      
      // 根据类型构建项目数据
      if (itemType === 'stock') {
        itemData = {
          ...itemData,
          ticker: formData.get('ticker-symbol'),
          name: formData.get('stock-name'),
          quantity: parseInt(formData.get('stock-quantity')),
          purchase_price: parseFloat(formData.get('purchase-price')),
          purchase_date: formData.get('purchase-date')
        };
      } else if (itemType === 'bond') {
        itemData = {
          ...itemData,
          name: formData.get('bond-name'),
          quantity: parseInt(formData.get('bond-quantity')),
          purchase_price: parseFloat(formData.get('bond-purchase-price')),
          purchase_date: formData.get('bond-purchase-date')
        };
      } else if (itemType === 'cash') {
        itemData = {
          ...itemData,
          name: formData.get('cash-name'),
          value: parseFloat(formData.get('cash-value'))
        };
      }
      
      // 添加或更新项目
      if (appState.selectedItem) {
        // 更新现有项目
        itemData.id = appState.selectedItem.id;
        await updatePortfolioItem(itemData);
      } else {
        // 添加新项目
        await addPortfolioItem(itemData);
      }
      
      // 重新加载数据
      await loadPortfolioData();
      
      // 关闭模态框
      closeModal();
      
      setLoading(false);
    } catch (error) {
      showError(`保存数据失败: ${error.message}`);
      setLoading(false);
    }
  }
  
  /**
   * 确认删除项目
   */
  function confirmDelete(item) {
    if (confirm(`确定要删除 "${item.name}" 吗？此操作无法撤销。`)) {
      deleteItem(item.id);
    }
  }
  
  /**
   * 删除投资项目
   */
  async function deleteItem(id) {
    try {
      setLoading(true);
      
      await deletePortfolioItem(id);
      
      // 重新加载数据
      await loadPortfolioData();
      
      setLoading(false);
    } catch (error) {
      showError(`删除失败: ${error.message}`);
      setLoading(false);
    }
  }
  
  /**
   * 更新所有图表
   */
  function updateCharts() {
    // 调用chart.js中的更新方法
    updatePerformanceChart(appState.portfolioItems);
    createAssetAllocationChart(appState.portfolioItems);
  }
  
  /**
 * 设置加载状态
 */
function setLoading(isLoading) {
    appState.isLoading = isLoading;
    elements.loadingIndicator.style.display = isLoading ? 'block' : 'none';
    
    // 在加载时禁用按钮
    elements.addItemBtn.disabled = isLoading;
    elements.refreshBtn.disabled = isLoading;
    
    // 更新鼠标指针
    document.body.style.cursor = isLoading ? 'wait' : 'default';
  }
  
  /**
   * 显示错误信息
   */
  function showError(message) {
    elements.errorContainer.textContent = message;
    elements.errorContainer.style.display = 'block';
    
    // 5秒后自动隐藏错误
    setTimeout(() => {
      hideError();
    }, 5000);
  }
  
  /**
   * 隐藏错误信息
   */
  function hideError() {
    elements.errorContainer.textContent = '';
    elements.errorContainer.style.display = 'none';
  }
  
  /**
   * 格式化货币值
   */
  function formatCurrency(value) {
    return new Intl.NumberFormat('zh-CN', {
      style: 'currency',
      currency: 'CNY',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  }
  
  /**
   * 初始化图表
   */
  function initializeCharts() {
    // 资产配置图表
    createAssetAllocationChart(appState.portfolioItems);
    
    // 业绩表现图表
    createPerformanceChart();
    
    // 风险分析图表
    createRiskAnalysisChart(appState.portfolioItems);
  }
  
  /**
   * 获取资产分配数据
   */
  function getAssetAllocationData() {
    // 初始化各资产类别的总值
    let stocksValue = 0;
    let bondsValue = 0;
    let cashValue = 0;
    let otherValue = 0;
    
    // 计算每种资产类别的总值
    appState.portfolioItems.forEach(item => {
      let itemValue = 0;
      
      if (item.type === 'stock') {
        itemValue = item.current_price * item.quantity;
        stocksValue += itemValue;
      } else if (item.type === 'bond') {
        itemValue = item.current_price * item.quantity;
        bondsValue += itemValue;
      } else if (item.type === 'cash') {
        itemValue = item.value;
        cashValue += itemValue;
      } else {
        itemValue = item.current_price * item.quantity;
        otherValue += itemValue;
      }
    });
    
    // 总投资组合价值
    const totalValue = stocksValue + bondsValue + cashValue + otherValue;
    
    // 计算每种资产类别的百分比
    const data = {
      labels: ['股票', '债券', '现金', '其他'],
      values: [
        (stocksValue / totalValue) * 100,
        (bondsValue / totalValue) * 100,
        (cashValue / totalValue) * 100,
        (otherValue / totalValue) * 100
      ]
    };
    
    // 过滤掉价值为0的类别
    const filteredLabels = [];
    const filteredValues = [];
    
    for (let i = 0; i < data.values.length; i++) {
      if (data.values[i] > 0) {
        filteredLabels.push(data.labels[i]);
        filteredValues.push(data.values[i]);
      }
    }
    
    return {
      labels: filteredLabels,
      values: filteredValues
    };
  }
  
  /**
   * 获取历史业绩数据
   */
  function getHistoricalPerformanceData() {
    // 这里可以从API获取真实数据，或使用模拟数据
    // 假设我们有6个月的历史数据
    return {
      labels: ['一月', '二月', '三月', '四月', '五月', '六月'],
      values: [
        appState.initialValue * 1.01,
        appState.initialValue * 1.02,
        appState.initialValue * 0.99,
        appState.initialValue * 1.03,
        appState.initialValue * 1.05,
        appState.totalValue
      ]
    };
  }
  
  /**
   * 检查投资项目是否为空
   */
  function isPortfolioEmpty() {
    return appState.portfolioItems.length === 0;
  }
  
  /**
   * 根据股票代码获取实时价格
   */
  async function getStockPrice(ticker) {
    try {
      const stockData = await fetchStockPrice(ticker);
      return stockData.price;
    } catch (error) {
      console.error(`获取${ticker}价格失败:`, error);
      return null;
    }
  }
  
  /**
   * 更新项目的当前价格
   */
  async function updateItemPrices() {
    for (const item of appState.portfolioItems) {
      if (item.type === 'stock' && item.ticker) {
        const price = await getStockPrice(item.ticker);
        if (price) {
          item.current_price = price;
        }
      }
    }
    
    // 更新UI
    renderPortfolioList();
    calculatePortfolioSummary();
    updateCharts();
  }
  
  /**
   * 获取风险分析数据
   */
  function getRiskAnalysisData() {
    // 简化的风险分析 - 根据资产类型分配风险值
    // 实际应用中应使用更复杂的风险模型
    const riskScores = {
      'stock': 0.7, // 高风险
      'bond': 0.3,  // 中等风险
      'cash': 0.1   // 低风险
    };
    
    let totalRiskScore = 0;
    let totalValue = 0;
    
    appState.portfolioItems.forEach(item => {
      let itemValue = 0;
      
      if (item.type === 'cash') {
        itemValue = item.value;
      } else {
        itemValue = item.current_price * item.quantity;
      }
      
      totalValue += itemValue;
      totalRiskScore += itemValue * (riskScores[item.type] || 0.5);
    });
    
    // 计算加权平均风险得分
    const portfolioRiskScore = totalValue > 0 ? totalRiskScore / totalValue : 0;
    
    // 将得分映射到风险类别
    let riskCategory;
    if (portfolioRiskScore < 0.2) {
      riskCategory = '低风险';
    } else if (portfolioRiskScore < 0.5) {
      riskCategory = '中等风险';
    } else {
      riskCategory = '高风险';
    }
    
    return {
      score: portfolioRiskScore,
      category: riskCategory,
      details: {
        diversification: calculateDiversificationScore(),
        volatility: calculateVolatilityScore(),
        liquidity: calculateLiquidityScore()
      }
    };
  }
  
  /**
   * 计算多样化得分
   */
  function calculateDiversificationScore() {
    // 简化的多样化评分
    const uniqueAssetTypes = new Set();
    const uniqueStocks = new Set();
    
    appState.portfolioItems.forEach(item => {
      uniqueAssetTypes.add(item.type);
      if (item.type === 'stock' && item.ticker) {
        uniqueStocks.add(item.ticker);
      }
    });
    
    // 计算多样化得分 (0-100)
    const assetTypeScore = Math.min(uniqueAssetTypes.size * 25, 50);
    const stockDiversityScore = Math.min(uniqueStocks.size * 5, 50);
    
    return assetTypeScore + stockDiversityScore;
  }
  
  /**
   * 计算波动性得分
   */
  function calculateVolatilityScore() {
    // 简化的波动性评分
    // 实际应用中应使用历史价格数据计算标准差
    
    // 使用资产类型比例作为代理
    let stocksValue = 0;
    let bondsValue = 0;
    let cashValue = 0;
    let totalValue = 0;
    
    appState.portfolioItems.forEach(item => {
      let itemValue = 0;
      
      if (item.type === 'cash') {
        itemValue = item.value;
        cashValue += itemValue;
      } else {
        itemValue = item.current_price * item.quantity;
        if (item.type === 'stock') {
          stocksValue += itemValue;
        } else if (item.type === 'bond') {
          bondsValue += itemValue;
        }
      }
      
      totalValue += itemValue;
    });
    
    // 股票比例越高，波动性得分越高
    const stocksRatio = totalValue > 0 ? stocksValue / totalValue : 0;
    
    // 将比例转换为0-100的得分
    return Math.round(stocksRatio * 100);
  }
  
  /**
   * 计算流动性得分
   */
  function calculateLiquidityScore() {
    // 简化的流动性评分
    // 现金最具流动性，其次是股票，然后是债券
    
    let cashValue = 0;
    let stocksValue = 0;
    let bondsValue = 0;
    let totalValue = 0;
    
    appState.portfolioItems.forEach(item => {
      let itemValue = 0;
      
      if (item.type === 'cash') {
        itemValue = item.value;
        cashValue += itemValue;
      } else {
        itemValue = item.current_price * item.quantity;
        if (item.type === 'stock') {
          stocksValue += itemValue;
        } else if (item.type === 'bond') {
          bondsValue += itemValue;
        }
      }
      
      totalValue += itemValue;
    });
    
    if (totalValue === 0) return 100; // 如果投资组合为空，返回最高流动性
    
    // 计算加权流动性得分
    const liquidityScore = (
      (cashValue * 100) + 
      (stocksValue * 80) + 
      (bondsValue * 50)
    ) / totalValue;
    
    return Math.round(liquidityScore);
  }
  
  // 在页面加载完成后初始化应用
  document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
  });
  