const Portfolio = require('../models/portfolioModel');


// Get all portfolio items
exports.getAllItems = async (req, res) => {
  try {
    const items = await Portfolio.getAllItems();
    res.status(200).json(items);
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving portfolio items', error: error.message });
  }
};

// Get stock info by symbol
exports.getStockInfo = async (req, res) =>  {
  try {
    const stockInfo = await Portfolio.getStockInfo(req.params.symbol);
    if (!stockInfo) {
      return res.status(404).json({ message: 'Stock info not found' });
    }
    res.status(200).json(stockInfo);
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving stock info', error: error.message });
  }
};
//Get my assets
exports.getMyAssets = async (req, res) => {
  try {
    const itemsBuy = await Portfolio.getBuyItemBySymbol(req.params.symbol);
    const itemsSell = await Portfolio.getSellItemBySymbol(req.params.symbol);

    // 计算买入的总数量
    const totalBuy = itemsBuy.reduce((sum, item) => sum + item.quantity, 0);
   
    // 计算卖出的总数量
    const totalSell = itemsSell.reduce((sum, item) => sum + item.quantity, 0);
   
    // 计算当前持有的股票数量
    const currentQuantity = totalBuy - totalSell;

    const asset_type = itemsBuy[0] ? itemsBuy[0].asset_type : 'unknown';
    const current_price = itemsBuy[0] ? itemsBuy[0].usd_amount : 0;

    // 构建返回的资产信息
    const item = {
      symbol: req.params.symbol,
      asset_type: asset_type,
      currentQuantity: currentQuantity,
      current_price: current_price,
    };
    res.status(200).json(item);
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving my assets', error: error.message });
  }
};

// Get a single portfolio item
exports.getItemTrend = async (req, res) => {
  try {
    const item = await Portfolio.getItemTrend(req.params.symbol);
    if (!item) {
      return res.status(404).json({ message: 'Item not found' });
    }
    res.status(200).json(item);
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving portfolio item', error: error.message });
  }
};

// Add buy/sell a new portfolio item
exports.createItem = async (req, res) => {
  try {
    const newItem = await Portfolio.createItem(req.body);
    res.status(201).json(newItem);
  } catch (error) {
    res.status(500).json({ message: 'Error creating portfolio item', error: error.message });
  }
};
