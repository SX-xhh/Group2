const { pool } = require('../config/dbdetails');

/**
 * 1. 新增交易明细（Create）
 * 功能：向 trade_details 表插入一条交易记录
 */
exports.createTrade = async (req, res) => {
  // 从请求体获取参数（对应表字段）
  const {
    user_id,
    stock_id,
    user_name,
    trade_type,
    trade_quantity,
    trade_price,
    total_amount,
    rate
  } = req.body;

  // 校验必填字段（根据业务需求，user_id、user_name 为必填）
  if (!user_id || !user_name) {
    return res.status(400).json({ error: 'user_id 和 user_name 为必填项' });
  }

  try {
    // 插入数据（使用参数化查询，防止SQL注入）
    const [result] = await pool.execute(`
      INSERT INTO trade_details (
        user_id, stock_id, user_name, trade_type,
        trade_quantity, trade_price, total_amount, rate
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      user_id,
      stock_id || null,  // 允许为null（若未指定股票ID）
      user_name,
      trade_type || null, // 允许为null（若未指定交易类型）
      trade_quantity || null,
      trade_price || null,
      total_amount || null,
      rate || 0.00  // 默认为0.00
    ]);

    // 返回新增的记录ID和成功信息
    res.status(201).json({
      success: true,
      message: '交易明细添加成功',
      data: {
        trade_id: result.insertId,  // 新增记录的自增ID
        ...req.body  // 返回传入的参数（方便前端确认）
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: '添加交易明细失败：' + error.message
    });
  }
};

/**
 * 2. 查询所有交易明细（Read All）
 * 功能：获取所有交易记录，支持按用户ID筛选（可选）
 */
exports.getAllTrades = async (req, res) => {
  try {
    // 支持按 user_id 筛选（URL参数：?user_id=1）
    const { user_id } = req.query;
    let query = 'SELECT * FROM trade_details ORDER BY trade_date DESC';
    const params = [];

    // 如果传入 user_id，则添加筛选条件
    if (user_id) {
      query = 'SELECT * FROM trade_details WHERE user_id = ? ORDER BY trade_date DESC';
      params.push(user_id);
    }

    // 执行查询
    const [trades] = await pool.execute(query, params);

    res.status(200).json({
      success: true,
      count: trades.length,  // 记录总数
      data: trades
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: '查询交易明细失败：' + error.message
    });
  }
};

/**
 * 3. 查询单个交易明细（Read One）
 * 功能：根据ID获取单条交易记录
 */
exports.getTradeById = async (req, res) => {
  const { id } = req.params;  // 从URL参数获取交易ID（如 /trades/1）

  try {
    const [trades] = await pool.execute(
      'SELECT * FROM trade_details WHERE id = ?',
      [id]
    );

    // 如果没有找到对应记录
    if (trades.length === 0) {
      return res.status(404).json({
        success: false,
        error: `未找到ID为 ${id} 的交易明细`
      });
    }

    // 返回找到的记录（取第一条，因为ID唯一）
    res.status(200).json({
      success: true,
      data: trades[0]
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: '查询交易明细失败：' + error.message
    });
  }
};

/**
 * 4. 更新交易明细（Update）
 * 功能：根据ID修改交易记录的字段
 */
exports.updateTrade = async (req, res) => {
  const { id } = req.params;  // 交易ID
  const {
    stock_id,
    trade_type,
    trade_quantity,
    trade_price,
    total_amount,
    rate
  } = req.body;  // 仅更新需要修改的字段（无需传所有字段）

  try {
    // 先检查记录是否存在
    const [existingTrade] = await pool.execute(
      'SELECT * FROM trade_details WHERE id = ?',
      [id]
    );
    if (existingTrade.length === 0) {
      return res.status(404).json({
        success: false,
        error: `未找到ID为 ${id} 的交易明细`
      });
    }

    // 执行更新（只更新传入的字段，未传入的保持不变）
    const [result] = await pool.execute(`
      UPDATE trade_details SET
        stock_id = IFNULL(?, stock_id),
        trade_type = IFNULL(?, trade_type),
        trade_quantity = IFNULL(?, trade_quantity),
        trade_price = IFNULL(?, trade_price),
        total_amount = IFNULL(?, total_amount),
        rate = IFNULL(?, rate)
      WHERE id = ?
    `, [
      stock_id,
      trade_type,
      trade_quantity,
      trade_price,
      total_amount,
      rate,
      id  // 最后一个参数是WHERE条件的ID
    ]);

    // 返回更新后的记录（重新查询一次）
    const [updatedTrade] = await pool.execute(
      'SELECT * FROM trade_details WHERE id = ?',
      [id]
    );

    res.status(200).json({
      success: true,
      message: '交易明细更新成功',
      data: updatedTrade[0]
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: '更新交易明细失败：' + error.message
    });
  }
};

/**
 * 5. 删除交易明细（Delete）
 * 功能：根据ID删除交易记录
 */
exports.deleteTrade = async (req, res) => {
  const { id } = req.params;

  try {
    // 先检查记录是否存在
    const [existingTrade] = await pool.execute(
      'SELECT * FROM trade_details WHERE id = ?',
      [id]
    );
    if (existingTrade.length === 0) {
      return res.status(404).json({
        success: false,
        error: `未找到ID为 ${id} 的交易明细`
      });
    }

    // 执行删除
    await pool.execute(
      'DELETE FROM trade_details WHERE id = ?',
      [id]
    );

    res.status(200).json({
      success: true,
      message: `ID为 ${id} 的交易明细已删除`
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: '删除交易明细失败：' + error.message
    });
  }
};