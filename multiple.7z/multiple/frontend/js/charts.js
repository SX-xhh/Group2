// Chart rendering functionality

let performanceChart = null;

// Initialize the performance chart
function initializeChart() {
  const ctx = document.getElementById('performanceChart').getContext('2d');
  
  // Create empty chart (will be populated later)
  performanceChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: [],
      datasets: [{
        label: 'Initial Value',
        backgroundColor: 'rgba(54, 162, 235, 0.5)',
        borderColor: 'rgb(54, 162, 235)',
        borderWidth: 1,
        data: [],
        performanceData: []
      }, {
        label: 'Current Value',
        backgroundColor: 'rgba(255, 99, 132, 0.5)',
        borderColor: 'rgb(255, 99, 132)',
        borderWidth: 1,
        data: [],
        performanceData: []
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          title: {
            display: true,
            text: 'Value ($)'
          }
        },
        x: {
          title: {
            display: true,
            text: 'Portfolio Items'
          }
        }
      },
      plugins: {
        tooltip: {
          callbacks: {
            footer: (tooltipItems) => {
              const item = tooltipItems[0].dataset.performanceData[tooltipItems[0].dataIndex];
              if (item && item.performance) {
                return `Performance: ${item.performance.toFixed(2)}%`;
              }
              return '';
            }
          }
        },
        legend: {
          position: 'top',
        }
      }
    }
  });
}

// Update the chart with new performance data
function updatePerformanceChart(performanceData) {
  if (!performanceChart) {
    initializeChart();
  }
  
  const labels = [];
  const initialValues = [];
  const currentValues = [];
  const performanceItems = [];
  
  // Extract data for chart
  performanceData.items.forEach(item => {
    labels.push(item.name);
    initialValues.push(parseFloat(item.initial_value));
    currentValues.push(parseFloat(item.current_value));
    performanceItems.push({
      name: item.name,
      performance: ((item.current_value - item.initial_value) / item.initial_value) * 100
    });
  });
  
  // Update chart data
  performanceChart.data.labels = labels;
  performanceChart.data.datasets[0].data = initialValues;
  performanceChart.data.datasets[1].data = currentValues;
  performanceChart.data.datasets[0].performanceData = performanceItems;
  performanceChart.data.datasets[1].performanceData = performanceItems;
  
  performanceChart.update();
}

// Create a pie chart showing asset allocation
function createAssetAllocationChart(portfolioItems) {
  // Remove previous chart if exists
  if (document.getElementById('allocationChart')) {
    document.getElementById('allocationChart').remove();
    const canvas = document.createElement('canvas');
    canvas.id = 'allocationChart';
    document.querySelector('.chart-container').appendChild(canvas);
  }
  
  // Calculate allocation by type
  const allocationData = {
    stock: 0,
    bond: 0,
    cash: 0
  };
  
  portfolioItems.forEach(item => {
    let value = 0;
    if (item.type === 'stock' || item.type === 'bond') {
      value = item.quantity * item.current_price;
    } else if (item.type === 'cash') {
      value = item.value;
    }
    allocationData[item.type] += value;
  });
  
  // Create pie chart
  const ctx = document.getElementById('allocationChart').getContext('2d');
  new Chart(ctx, {
    type: 'pie',
    data: {
      labels: ['Stocks', 'Bonds', 'Cash'],
      datasets: [{
        data: [
          allocationData.stock, 
          allocationData.bond, 
          allocationData.cash
        ],
        backgroundColor: [
          'rgba(46, 204, 113, 0.7)',
          'rgba(243, 156, 18, 0.7)',
          'rgba(155, 89, 182, 0.7)'
        ],
        borderColor: [
          'rgb(46, 204, 113)',
          'rgb(243, 156, 18)',
          'rgb(155, 89, 182)'
        ],
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'right',
        },
        tooltip: {
          callbacks: {
            label: (tooltipItem) => {
              const total = tooltipItem.dataset.data.reduce((a, b) => a + b, 0);
              const value = tooltipItem.raw;
              const percentage = ((value / total) * 100).toFixed(2);
              return `${tooltipItem.label}: $${value.toFixed(2)} (${percentage}%)`;
            }
          }
        }
      }
    }
  });
}

// Toggle between performance and allocation charts
function toggleChartView() {
  const performanceChart = document.getElementById('performanceChart');
  const allocationChart = document.getElementById('allocationChart');
  
  if (performanceChart.style.display === 'none') {
    performanceChart.style.display = 'block';
    allocationChart.style.display = 'none';
  } else {
    performanceChart.style.display = 'none';
    allocationChart.style.display = 'block';
  }
}

// Create historical performance line chart
function createHistoricalChart(historicalData) {
  // Remove previous chart if exists
  if (document.getElementById('historicalChart')) {
    document.getElementById('historicalChart').remove();
    const canvas = document.createElement('canvas');
    canvas.id = 'historicalChart';
    document.querySelector('.chart-container').appendChild(canvas);
  }
  
  const dates = historicalData.map(item => item.date);
  const values = historicalData.map(item => item.value);
  
  const ctx = document.getElementById('historicalChart').getContext('2d');
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: dates,
      datasets: [{
        label: 'Portfolio Value Over Time',
        data: values,
        fill: false,
        borderColor: 'rgb(75, 192, 192)',
        tension: 0.1
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: false,
          title: {
            display: true,
            text: 'Value ($)'
          }
        },
        x: {
          title: {
            display: true,
            text: 'Date'
          }
        }
      }
    }
  });
}

// Export chart functions
window.chartFunctions = {
  initializeChart,
  updatePerformanceChart,
  createAssetAllocationChart,
  toggleChartView,
  createHistoricalChart
};
